// ═══════════════════════════════════════════════════════════════════════════
// IGP GENERATOR — vector line tiles (Hankin method)
// ═══════════════════════════════════════════════════════════════════════════

let socket;
let canvas;

// ─── Tiles ────────────────────────────────────────────────────────────────────
// Each tile: { id, wx, wy, theta, tilingType, color, segs, scale, revealProgress }
let placedTiles = [];
let pendingTiles = [];

const TILE_SIZE = 120; // px — diameter of each placed tile in world space
const REVEAL_DUR = 800; // ms for draw-on animation

// ─── IGP settings ─────────────────────────────────────────────────────────────
let igpTheta = Math.PI / 4;
let igpTiling = "squareOctagon";
let igpMainColor = "#1a4a8a";

// ─── Touch ────────────────────────────────────────────────────────────────────
let touchX = -9999,
  touchY = -9999;
let touchStartX = -9999,
  touchStartY = -9999;
let isTouching = false;
let longPressTimer = null;
let longPressX = 0,
  longPressY = 0;
const LONG_PRESS_MS = 500;

// ─── Ripples ──────────────────────────────────────────────────────────────────
const RIPPLE_SPEED = 280;
const RIPPLE_FORCE = 9;
const RIPPLE_WIDTH = 40;
const RIPPLE_DURATION = 1400;
let ripples = [];

// ─── Pan ──────────────────────────────────────────────────────────────────────
let panX = 0,
  panY = 0;
let panVX = 0,
  panVY = 0;
let isPanning = false;
let panLastX = 0,
  panLastY = 0;
let worldW, worldH;
const PAN_DAMPING = 0.88;

// ─── Modal / preview ──────────────────────────────────────────────────────────
let igpModalOpen = false;
let previewDragY = 0;
let previewLastX = null,
  previewLastY = null;
let previewSegCache = null,
  previewSegKey = null,
  previewBBox = null;

const TILINGS = ["squareOctagon", "rhombitrihexagonal"];
const TILING_LABELS = {
  squareOctagon: "Sq-Octagon",
  rhombitrihexagonal: "3-4-6-4",
};

// ─── Multi-user ───────────────────────────────────────────────────────────────
const TOUCH_SYNC_THROTTLE = 50;
let lastTouchSyncTime = 0;
const remoteUsers = new Map();
let userId = null;

// ─── Audio ────────────────────────────────────────────────────────────────────
let audioContext = null,
  masterGain = null;
let lastPluckTime = 0;
const PLUCK_COOLDOWN = 100;

function initAudio() {
  if (audioContext) return;
  audioContext = new (window.AudioContext || window.webkitAudioContext)();
  masterGain = audioContext.createGain();
  masterGain.gain.value = 0.25;
  masterGain.connect(audioContext.destination);
}

function playPluck(x) {
  if (!audioContext) return;
  const now = Date.now();
  if (now - lastPluckTime < PLUCK_COOLDOWN) return;
  lastPluckTime = now;
  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();
  osc.type = "triangle";
  osc.frequency.value = 300 + (x / worldW) * 500;
  gain.gain.setValueAtTime(0.3, audioContext.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.15);
  osc.connect(gain);
  gain.connect(masterGain);
  osc.start(audioContext.currentTime);
  osc.stop(audioContext.currentTime + 0.15);
}

// ═══════════════════════════════════════════════════════════════════════════
// HANKIN ENGINE
// ═══════════════════════════════════════════════════════════════════════════
function hankinIntersect(e1a, e1b, e2a, e2b) {
  const x1 = e1a.x,
    y1 = e1a.y,
    x2 = e1b.x,
    y2 = e1b.y;
  const x3 = e2a.x,
    y3 = e2a.y,
    x4 = e2b.x,
    y4 = e2b.y;
  const denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
  if (Math.abs(denom) < 1e-9) return null;
  const t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom;
  return { x: x1 + t * (x2 - x1), y: y1 + t * (y2 - y1) };
}

function rotVec(vx, vy, a) {
  return {
    x: vx * Math.cos(a) - vy * Math.sin(a),
    y: vx * Math.sin(a) + vy * Math.cos(a),
  };
}

function centroid(verts) {
  let cx = 0,
    cy = 0;
  for (const v of verts) {
    cx += v.x;
    cy += v.y;
  }
  return { x: cx / verts.length, y: cy / verts.length };
}

function hankinLines(verts, theta) {
  const cen = centroid(verts);
  const lines = [];
  const n = verts.length;
  for (let i = 0; i < n; i++) {
    const a = verts[i],
      b = verts[(i + 1) % n];
    const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
    const len = Math.sqrt((b.x - a.x) ** 2 + (b.y - a.y) ** 2);
    const ex = (b.x - a.x) / len,
      ey = (b.y - a.y) / len;
    let px = -ey,
      py = ex;
    if (px * (cen.x - mid.x) + py * (cen.y - mid.y) < 0) {
      px = -px;
      py = -py;
    }
    const dA = rotVec(px, py, theta),
      dB = rotVec(px, py, -theta);
    const pt = hankinIntersect(a, { x: a.x + dA.x, y: a.y + dA.y }, b, {
      x: b.x + dB.x,
      y: b.y + dB.y,
    });
    if (!pt) continue;
    lines.push({ ax: a.x, ay: a.y, bx: pt.x, by: pt.y });
    lines.push({ ax: b.x, ay: b.y, bx: pt.x, by: pt.y });
  }
  return lines;
}

function buildUnitPolygons(tilingType, size) {
  const polys = [];
  if (tilingType === "squareOctagon") {
    const r8 = size / (2 * Math.cos(Math.PI / 8));
    const oct = [];
    for (let k = 0; k < 8; k++) {
      const a = Math.PI / 8 + (k * Math.PI * 2) / 8;
      oct.push({ x: r8 * Math.cos(a), y: r8 * Math.sin(a) });
    }
    polys.push(oct);
    const a2 = size / (1 + Math.sqrt(2));
    for (const o of [
      { x: size * 0.5 + a2 * 0.5, y: 0 },
      { x: -(size * 0.5 + a2 * 0.5), y: 0 },
      { x: 0, y: size * 0.5 + a2 * 0.5 },
      { x: 0, y: -(size * 0.5 + a2 * 0.5) },
    ]) {
      const h = a2 / 2;
      polys.push([
        { x: o.x - h, y: o.y - h },
        { x: o.x + h, y: o.y - h },
        { x: o.x + h, y: o.y + h },
        { x: o.x - h, y: o.y + h },
      ]);
    }
  } else if (tilingType === "rhombitrihexagonal") {
    const rH = size * 0.38,
      sH = (rH * Math.sqrt(3)) / 2;
    const hex = [];
    for (let k = 0; k < 6; k++) {
      const a = Math.PI / 6 + (k * Math.PI) / 3;
      hex.push({ x: rH * Math.cos(a), y: rH * Math.sin(a) });
    }
    polys.push(hex);
    for (let k = 0; k < 6; k++) {
      const a = Math.PI / 6 + (k * Math.PI) / 3;
      const scx = (rH + sH) * Math.cos(a),
        scy = (rH + sH) * Math.sin(a);
      const nx = Math.cos(a + Math.PI / 2) * sH,
        ny = Math.sin(a + Math.PI / 2) * sH;
      const rx = Math.cos(a) * sH,
        ry = Math.sin(a) * sH;
      polys.push([
        { x: scx - nx - rx, y: scy - ny - ry },
        { x: scx + nx - rx, y: scy + ny - ry },
        { x: scx + nx + rx, y: scy + ny + ry },
        { x: scx - nx + rx, y: scy - ny + ry },
      ]);
    }
    for (let k = 0; k < 6; k++) {
      const a1 = Math.PI / 6 + (k * Math.PI) / 3,
        a2 = Math.PI / 6 + ((k + 1) * Math.PI) / 3,
        amid = (a1 + a2) / 2,
        tR = rH + sH * 2;
      polys.push([
        {
          x:
            (rH + sH) * Math.cos(a1) +
            Math.cos(a1 + Math.PI / 2) * sH +
            Math.cos(a1) * sH,
          y:
            (rH + sH) * Math.sin(a1) +
            Math.sin(a1 + Math.PI / 2) * sH +
            Math.sin(a1) * sH,
        },
        {
          x:
            (rH + sH) * Math.cos(a2) -
            Math.cos(a2 + Math.PI / 2) * sH +
            Math.cos(a2) * sH,
          y:
            (rH + sH) * Math.sin(a2) -
            Math.sin(a2 + Math.PI / 2) * sH +
            Math.sin(a2) * sH,
        },
        { x: tR * Math.cos(amid), y: tR * Math.sin(amid) },
      ]);
    }
  }
  return polys;
}

// Build normalised segments (unit scale, bbox-fitted) for a tile
// Returns { segs, scale } where segs are ready to draw centered at (0,0)
function buildTileSegs(theta, tilingType) {
  const unitPolys = buildUnitPolygons(tilingType, 1.0);
  const allSegs = [];
  for (const verts of unitPolys)
    for (const s of hankinLines(verts, theta)) allSegs.push(s);
  if (!allSegs.length) return { segs: [], sc: 1, ox: 0, oy: 0 };

  let minX = Infinity,
    maxX = -Infinity,
    minY = Infinity,
    maxY = -Infinity;
  for (const s of allSegs) {
    minX = Math.min(minX, s.ax, s.bx);
    maxX = Math.max(maxX, s.ax, s.bx);
    minY = Math.min(minY, s.ay, s.by);
    maxY = Math.max(maxY, s.ay, s.by);
  }
  const range = Math.max(maxX - minX, maxY - minY);
  const sc = (TILE_SIZE * 0.92) / range;
  const ox = -((minX + (maxX - minX) / 2) * sc);
  const oy = -((minY + (maxY - minY) / 2) * sc);
  return { segs: allSegs, sc, ox, oy };
}

// ═══════════════════════════════════════════════════════════════════════════
// p5 SETUP
// ═══════════════════════════════════════════════════════════════════════════
function setup() {
  socket =
    location.hostname.toLowerCase().startsWith("browsercircus") ||
    location.hostname.toLowerCase().startsWith("www")
      ? io({ path: "/canvas-photo/socket.io" })
      : io();

  userId = "user_" + Math.random().toString(36).substr(2, 9);

  socket.on("historic-tiles", (savedTiles) => {
    for (const t of savedTiles) restoreTile(t);
    loop();
  });
  socket.on("new-tile", (t) => {
    restoreTile(t);
    loop();
  });
  socket.on("user-touch-move", ({ userId: uid, x, y }) => {
    if (uid === userId) return;
    const u = remoteUsers.get(uid) || {};
    remoteUsers.set(uid, {
      ...u,
      x,
      y,
      lastUpdate: Date.now(),
      isActive: true,
    });
    loop();
  });
  socket.on("user-touch-end", ({ userId: uid }) => {
    const u = remoteUsers.get(uid);
    if (u) {
      u.isActive = false;
      setTimeout(() => remoteUsers.delete(uid), 500);
    }
    loop();
  });

  canvas = createCanvas(windowWidth, windowHeight);
  canvas.parent("mandala-screen");

  document.querySelector("#introButton")?.addEventListener("click", () => {
    document.querySelector("#intro-screen").style.display = "none";
    showMandalaScreen();
  });
  document.addEventListener("click", initAudio, { once: true });
  document.addEventListener("touchstart", initAudio, { once: true });
  noLoop();
}

// ═══════════════════════════════════════════════════════════════════════════
// p5 DRAW
// ═══════════════════════════════════════════════════════════════════════════
function draw() {
  background("#0a0a0f");

  // Pan momentum
  if (!isPanning && (Math.abs(panVX) > 0.1 || Math.abs(panVY) > 0.1)) {
    panX += panVX;
    panY += panVY;
    panVX *= PAN_DAMPING;
    panVY *= PAN_DAMPING;
    clampPan();
  }

  push();
  translate(panX, panY);

  // Grid dots
  drawGridDots();

  const now = millis();
  let anyAnimating = false;

  ripples = ripples.filter((r) => now - r.startTime < RIPPLE_DURATION);
  const hasRipple = ripples.length > 0;

  // Draw each vector tile
  for (const tile of placedTiles) {
    // Reveal animation: draw lines progressively
    let progress = 1;
    if (tile.revealStart) {
      const elapsed = now - tile.revealStart;
      progress = Math.min(1, elapsed / REVEAL_DUR);
      if (progress < 1) anyAnimating = true;
      else tile.revealStart = null;
    }

    // Physics: tile shifts as a whole unit
    if (isTouching) {
      const dx = tile.wx - touchX,
        dy = tile.wy - touchY;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d < REPULSION_RADIUS && d > 0) {
        const str = (1 - d / REPULSION_RADIUS) * REPULSION_FORCE * 0.4;
        tile.vx += (dx / d) * str;
        tile.vy += (dy / d) * str;
        playPluck(tile.wx);
      }
    }
    for (const [, u] of remoteUsers) {
      if (!u.isActive) continue;
      const dx = tile.wx - u.x,
        dy = tile.wy - u.y;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d < REPULSION_RADIUS && d > 0) {
        const str = (1 - d / REPULSION_RADIUS) * REPULSION_FORCE * 0.4;
        tile.vx += (dx / d) * str;
        tile.vy += (dy / d) * str;
      }
    }
    if (hasRipple) {
      for (const r of ripples) {
        const elapsed = now - r.startTime;
        const waveFront = (elapsed / 1000) * RIPPLE_SPEED;
        const dx = tile.wx - r.x,
          dy = tile.wy - r.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        const diff = d - waveFront;
        if (Math.abs(diff) < RIPPLE_WIDTH) {
          const str =
            Math.exp((-diff * diff) / (RIPPLE_WIDTH * RIPPLE_WIDTH * 0.5)) *
            RIPPLE_FORCE *
            (1 - elapsed / RIPPLE_DURATION) *
            0.4;
          if (d > 0) {
            tile.vx += (dx / d) * str;
            tile.vy += (dy / d) * str;
          }
        }
      }
    }

    // Spring back to home
    tile.vx += -tile.dx * 0.12;
    tile.vy += -tile.dy * 0.12;
    tile.vx *= 0.76;
    tile.vy *= 0.76;
    tile.dx += tile.vx;
    tile.dy += tile.vy;
    if (
      Math.abs(tile.vx) +
        Math.abs(tile.vy) +
        Math.abs(tile.dx) +
        Math.abs(tile.dy) >
      0.05
    )
      anyAnimating = true;

    drawVectorTile(tile, progress);
  }

  pop();

  // Touch indicators
  for (const [, u] of remoteUsers)
    if (u.isActive) drawTouchIndicator(u.x + panX, u.y + panY, 77);
  if (isTouching) drawTouchIndicator(touchX + panX, touchY + panY, 255);

  const anyRemoteActive = [...remoteUsers.values()].some((u) => u.isActive);
  if (
    !anyAnimating &&
    !isTouching &&
    !hasRipple &&
    Math.abs(panVX) < 0.1 &&
    Math.abs(panVY) < 0.1 &&
    !anyRemoteActive
  )
    noLoop();
}

const REPULSION_RADIUS = 150;
const REPULSION_FORCE = 5;

function drawVectorTile(tile, progress) {
  const cx = tile.wx + tile.dx;
  const cy = tile.wy + tile.dy;
  const { segs, sc, ox, oy } = tile;
  if (!segs || !segs.length) return;

  push();
  translate(cx, cy);

  stroke(tile.color);
  strokeWeight(1.2);
  noFill();

  // Draw only `progress` fraction of segments (reveal animation)
  const count = Math.floor(segs.length * progress);
  for (let i = 0; i < count; i++) {
    const s = segs[i];
    line(s.ax * sc + ox, s.ay * sc + oy, s.bx * sc + ox, s.by * sc + oy);
  }

  pop();
}

function drawTouchIndicator(sx, sy, alpha) {
  push();
  noStroke();
  fill(255, 255, 255, alpha);
  textSize(18);
  textAlign(CENTER, CENTER);
  text("✦", sx, sy);
  pop();
}

function drawGridDots() {
  const startCol = Math.max(0, Math.floor(-panX / 40) - 1);
  const startRow = Math.max(0, Math.floor(-panY / 40) - 1);
  const endCol = Math.min(
    Math.ceil(worldW / 40) + 1,
    startCol + Math.ceil(width / 40) + 2,
  );
  const endRow = Math.min(
    Math.ceil(worldH / 40) + 1,
    startRow + Math.ceil(height / 40) + 2,
  );
  fill(255, 255, 255, 18);
  noStroke();
  for (let c = startCol; c <= endCol; c++)
    for (let r = startRow; r <= endRow; r++) ellipse(c * 40, r * 40, 2, 2);
}

// ═══════════════════════════════════════════════════════════════════════════
// TILE PLACEMENT
// ═══════════════════════════════════════════════════════════════════════════
function addOneTile() {
  // Random position in visible area
  const margin = TILE_SIZE;
  const wx = -panX + margin + Math.random() * (width - margin * 2);
  const wy = -panY + margin + Math.random() * (height - margin * 2);

  const id = `${Math.round(wx)}_${Math.round(wy)}_${Date.now()}`;
  placeTileAt(id, wx, wy, igpTheta, igpTiling, igpMainColor, true);

  socket.emit("new-tile", {
    id,
    wx,
    wy,
    theta: igpTheta,
    tiling: igpTiling,
    mainColor: igpMainColor,
  });
}

function restoreTile(t) {
  if (typeof t.theta !== "number" || !t.tiling || !t.mainColor) return;
  // Support both old col/row format and new wx/wy format
  const wx = t.wx !== undefined ? t.wx : t.col * 6;
  const wy = t.wy !== undefined ? t.wy : t.row * 6;
  const id = t.id || `${t.col}_${t.row}`;
  placeTileAt(id, wx, wy, t.theta, t.tiling, t.mainColor, false);
}

function placeTileAt(id, wx, wy, theta, tilingType, color, animate) {
  if (placedTiles.find((t) => t.id === id)) return;
  const { segs, sc, ox, oy } = buildTileSegs(theta, tilingType);
  placedTiles.push({
    id,
    wx,
    wy,
    theta,
    tilingType,
    color,
    segs,
    sc,
    ox,
    oy,
    dx: 0,
    dy: 0,
    vx: 0,
    vy: 0,
    revealStart: animate ? millis() : null,
  });
  loop();
}

// ═══════════════════════════════════════════════════════════════════════════
// WORLD / PAN
// ═══════════════════════════════════════════════════════════════════════════
function initWorld() {
  worldW = width * 4;
  worldH = height * 4;
  panX = -(worldW - width) / 2;
  panY = -(worldH - height) / 2;
  panVX = 0;
  panVY = 0;
  placedTiles = [];
  ripples = [];
}

function clampPan() {
  panX = Math.min(0, Math.max(-(worldW - width), panX));
  panY = Math.min(0, Math.max(-(worldH - height), panY));
}

function screenToWorld(sx, sy) {
  return { x: sx - panX, y: sy - panY };
}

function showMandalaScreen() {
  document.querySelector("#mandala-screen").style.display = "block";
  canvas.parent("mandala-screen");
  resizeCanvas(windowWidth, windowHeight);
  initWorld();
  // Restore pending tiles now that world is initialized
  for (const t of pendingTiles) restoreTile(t);
  pendingTiles = [];
  loop();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  initWorld();
  redraw();
}

// ═══════════════════════════════════════════════════════════════════════════
// TOUCH / MOUSE
// ═══════════════════════════════════════════════════════════════════════════
function touchStarted() {
  if (igpModalOpen) return;
  if (touches[0]) {
    const el = document.elementFromPoint(touches[0].x, touches[0].y);
    if (
      el &&
      (el.tagName === "BUTTON" ||
        el.closest("button") ||
        el.closest("#igp-modal"))
    )
      return;
  }
  if (touches.length >= 2) {
    cancelLongPress();
    isPanning = true;
    isTouching = false;
    panLastX = (touches[0].x + touches[1].x) / 2;
    panLastY = (touches[0].y + touches[1].y) / 2;
    panVX = 0;
    panVY = 0;
  } else if (touches.length === 1) {
    isPanning = false;
    const w = screenToWorld(touches[0].x, touches[0].y);
    touchX = w.x;
    touchY = w.y;
    touchStartX = w.x;
    touchStartY = w.y;
    isTouching = true;
    longPressX = touches[0].x;
    longPressY = touches[0].y;
    longPressTimer = setTimeout(() => {
      isTouching = false;
      cancelLongPress();
      openIGPModal();
    }, LONG_PRESS_MS);
  }
  loop();
  return false;
}

function touchMoved() {
  if (igpModalOpen) return false;
  if (isPanning && touches.length >= 2) {
    const cx = (touches[0].x + touches[1].x) / 2,
      cy = (touches[0].y + touches[1].y) / 2;
    panVX = cx - panLastX;
    panVY = cy - panLastY;
    panX += panVX;
    panY += panVY;
    clampPan();
    panLastX = cx;
    panLastY = cy;
    document.getElementById("pan-hint")?.classList.add("hidden");
    loop();
    return false;
  }
  if (isTouching && touches.length === 1) {
    const w = screenToWorld(touches[0].x, touches[0].y);
    touchX = w.x;
    touchY = w.y;
    if (
      Math.sqrt(
        (touches[0].x - longPressX) ** 2 + (touches[0].y - longPressY) ** 2,
      ) > 10
    )
      cancelLongPress();
    if (Math.random() < 0.15)
      ripples.push({ x: touchX, y: touchY, startTime: millis() });
    const now = Date.now();
    if (now - lastTouchSyncTime > TOUCH_SYNC_THROTTLE) {
      socket.emit("user-touch-move", { userId, x: touchX, y: touchY });
      lastTouchSyncTime = now;
    }
    loop();
    return false;
  }
}

function touchEnded() {
  cancelLongPress();
  if (isPanning) {
    isPanning = false;
    loop();
    return false;
  }
  if (!isTouching) return;
  isTouching = false;
  if (
    Math.sqrt((touchX - touchStartX) ** 2 + (touchY - touchStartY) ** 2) < 14
  ) {
    ripples.push({ x: touchX, y: touchY, startTime: millis() });
  }
  socket.emit("user-touch-end", { userId });
  loop();
  return false;
}

function cancelLongPress() {
  if (longPressTimer) {
    clearTimeout(longPressTimer);
    longPressTimer = null;
  }
}

function mouseMoved() {
  if (igpModalOpen) return;
  const w = screenToWorld(mouseX, mouseY);
  touchX = w.x;
  touchY = w.y;
  isTouching = true;
  loop();
}
function mousePressed() {
  if (igpModalOpen) return;
  const w = screenToWorld(mouseX, mouseY);
  touchStartX = w.x;
  touchStartY = w.y;
  longPressX = mouseX;
  longPressY = mouseY;
  longPressTimer = setTimeout(() => {
    cancelLongPress();
    isTouching = false;
    openIGPModal();
  }, LONG_PRESS_MS);
}
function mouseReleased() {
  cancelLongPress();
  if (igpModalOpen) return;
  isTouching = false;
  const w = screenToWorld(mouseX, mouseY);
  if (Math.sqrt((w.x - touchStartX) ** 2 + (w.y - touchStartY) ** 2) < 14)
    ripples.push({ x: w.x, y: w.y, startTime: millis() });
  socket.emit("user-touch-end", { userId });
}
function mouseDragged() {
  if (Math.sqrt((mouseX - longPressX) ** 2 + (mouseY - longPressY) ** 2) > 10)
    cancelLongPress();
  if (isTouching) {
    const now = Date.now();
    if (now - lastTouchSyncTime > TOUCH_SYNC_THROTTLE) {
      socket.emit("user-touch-move", { userId, x: touchX, y: touchY });
      lastTouchSyncTime = now;
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// IGP MODAL
// ═══════════════════════════════════════════════════════════════════════════
function openIGPModal() {
  igpModalOpen = true;
  previewDragY = TILINGS.indexOf(igpTiling);
  previewLastX = null;
  previewLastY = null;
  document.getElementById("igp-modal").style.display = "flex";
  document.querySelector("canvas").style.pointerEvents = "none";
  document.getElementById("pan-hint")?.classList.add("hidden");

  document.getElementById("igp-color-main").value = igpMainColor;
  document.getElementById("swatch-main").style.background = igpMainColor;
  document.getElementById("igp-color-main").oninput = (e) => {
    igpMainColor = e.target.value;
    document.getElementById("swatch-main").style.background = igpMainColor;
    renderPreview();
  };

  document.querySelectorAll(".tiling-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.tiling === igpTiling);
    btn.onclick = function () {
      igpTiling = this.dataset.tiling;
      previewDragY = TILINGS.indexOf(igpTiling);
      document
        .querySelectorAll(".tiling-btn")
        .forEach((b) => b.classList.remove("active"));
      this.classList.add("active");
      renderPreview();
    };
  });

  initPreviewCanvas();
  document.getElementById("igp-close").onclick = closeIGPModal;
  document.getElementById("igp-apply").onclick = applyAndGenerate;
}

function closeIGPModal() {
  igpModalOpen = false;
  document.getElementById("igp-modal").style.display = "none";
  document.querySelector("canvas").style.pointerEvents = "auto";
  const ctr = document.getElementById("igp-canvas-container");
  ctr.removeEventListener("touchstart", prevTouchStart);
  ctr.removeEventListener("touchmove", prevTouchMove);
  ctr.removeEventListener("touchend", prevTouchEnd);
  ctr.removeEventListener("mousemove", prevMouseMove);
}

function applyAndGenerate() {
  closeIGPModal();
  addOneTile();
}

// ─── Preview canvas ───────────────────────────────────────────────────────────
function initPreviewCanvas() {
  const ctr = document.getElementById("igp-canvas-container");
  const side = Math.round(ctr.getBoundingClientRect().width);
  let cvs = document.getElementById("igp-canvas");
  if (!cvs) {
    cvs = document.createElement("canvas");
    cvs.id = "igp-canvas";
    ctr.prepend(cvs);
  }
  cvs.width = side;
  cvs.height = side;
  ctr.addEventListener("touchstart", prevTouchStart, { passive: false });
  ctr.addEventListener("touchmove", prevTouchMove, { passive: false });
  ctr.addEventListener("touchend", prevTouchEnd, { passive: false });
  ctr.addEventListener("mousemove", prevMouseMove);
  renderPreview();
}

function prevTouchStart(e) {
  e.preventDefault();
  const t = e.touches[0];
  previewLastX = t.clientX;
  previewLastY = t.clientY;
}

function prevTouchMove(e) {
  e.preventDefault();
  if (!previewLastX) return;
  const cvs = document.getElementById("igp-canvas");
  if (!cvs) return;
  const t = e.touches[0];
  const dx = t.clientX - previewLastX,
    dy = t.clientY - previewLastY;
  igpTheta = Math.max(
    (10 * Math.PI) / 180,
    Math.min(
      (80 * Math.PI) / 180,
      igpTheta + (dx * ((70 * Math.PI) / 180)) / cvs.width,
    ),
  );
  previewDragY = Math.max(
    0,
    Math.min(TILINGS.length - 1, previewDragY - dy / 80),
  );
  const idx = Math.round(previewDragY);
  if (TILINGS[idx] !== igpTiling) {
    igpTiling = TILINGS[idx];
    document
      .querySelectorAll(".tiling-btn")
      .forEach((b) =>
        b.classList.toggle("active", b.dataset.tiling === igpTiling),
      );
  }
  document.getElementById("igp-angle-val").textContent =
    Math.round((igpTheta * 180) / Math.PI) + "°";
  previewLastX = t.clientX;
  previewLastY = t.clientY;
  renderPreview();
}

function prevTouchEnd() {
  previewLastX = null;
  previewLastY = null;
}

let _mouseThrottle = 0;
function prevMouseMove(e) {
  const now = Date.now();
  if (now - _mouseThrottle < 32) return;
  _mouseThrottle = now;
  const cvs = document.getElementById("igp-canvas");
  if (!cvs) return;
  const rect = cvs.getBoundingClientRect();
  igpTheta =
    ((10 + ((e.clientX - rect.left) / rect.width) * 70) * Math.PI) / 180;
  document.getElementById("igp-angle-val").textContent =
    Math.round((igpTheta * 180) / Math.PI) + "°";
  renderPreview();
}

function renderPreview() {
  const cvs = document.getElementById("igp-canvas");
  if (!cvs) return;
  const ctx = cvs.getContext("2d");
  const W = cvs.width,
    H = cvs.height;

  ctx.fillStyle = "#0a0a0f";
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = "rgba(255,255,255,0.1)";
  for (let x = 0; x <= W; x += 6)
    for (let y = 0; y <= H; y += 6) {
      ctx.beginPath();
      ctx.arc(x, y, 0.7, 0, Math.PI * 2);
      ctx.fill();
    }

  const segKey = `${igpTiling}_${Math.round(igpTheta * 1000)}`;
  if (segKey !== previewSegKey) {
    const allSegs = [];
    for (const verts of buildUnitPolygons(igpTiling, 1.0))
      for (const s of hankinLines(verts, igpTheta)) allSegs.push(s);
    if (allSegs.length) {
      let minX = Infinity,
        maxX = -Infinity,
        minY = Infinity,
        maxY = -Infinity;
      for (const s of allSegs) {
        minX = Math.min(minX, s.ax, s.bx);
        maxX = Math.max(maxX, s.ax, s.bx);
        minY = Math.min(minY, s.ay, s.by);
        maxY = Math.max(maxY, s.ay, s.by);
      }
      previewBBox = { minX, maxX, minY, maxY };
      previewSegCache = allSegs;
    }
    previewSegKey = segKey;
  }
  if (!previewSegCache?.length) return;

  const { minX, maxX, minY, maxY } = previewBBox;
  const range = Math.max(maxX - minX, maxY - minY);
  const sc = (Math.min(W, H) * 0.88) / range;
  const ox = W / 2 - (minX + (maxX - minX) / 2) * sc;
  const oy = H / 2 - (minY + (maxY - minY) / 2) * sc;

  ctx.strokeStyle = igpMainColor;
  ctx.lineWidth = 1.5;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  for (const s of previewSegCache) {
    ctx.moveTo(s.ax * sc + ox, s.ay * sc + oy);
    ctx.lineTo(s.bx * sc + ox, s.by * sc + oy);
  }
  ctx.stroke();

  const deg = Math.round((igpTheta * 180) / Math.PI);
  ctx.fillStyle = "rgba(255,255,255,0.4)";
  ctx.font = "11px 'Cormorant Garamond',serif";
  ctx.textAlign = "center";
  ctx.fillText("← drag to change angle", W / 2, H - 10);
  ctx.fillStyle = "rgba(255,255,255,0.6)";
  ctx.font = "bold 13px 'Cinzel',serif";
  ctx.fillText(`${TILING_LABELS[igpTiling]}  ·  ${deg}°`, W / 2, 22);
}
